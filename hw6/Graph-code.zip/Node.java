


public class Node {
	protected String element;
	
	public Node(String element) {
		this.element = element;
	}
	
	public String getElement() {
		return element;
	}
	
	public String toString() {
		return element;
	}

}
